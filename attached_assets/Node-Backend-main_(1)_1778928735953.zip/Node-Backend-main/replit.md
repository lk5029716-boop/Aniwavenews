# Aniwaves API

A production-ready Node.js/Express backend that wraps Aniwaves.ru to expose a clean anime streaming API. Returns direct playable HLS (`.m3u8`) URLs for any anime episode.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port from `$PORT`, default 8080)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `SESSION_SECRET` — express-session secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- HTTP: axios
- Scraping: cheerio
- Caching: node-cache (in-memory, TTL per resource)
- Build: esbuild (ESM bundle)
- Logging: pino (7-stage verbose logging)

## Where things live

```
artifacts/api-server/src/
  routes/
    anime.ts          — all 6 anime API route handlers
    index.ts          — router aggregator
  lib/anime/
    scraper.ts        — Aniwaves.ru scraping: search, details, episodes, servers, embed URL
    cache.ts          — NodeCache singleton with per-resource TTLs
    types.ts          — shared TypeScript interfaces
    providers/
      index.ts        — provider dispatch (route embedUrl to correct extractor)
      echovideo.ts    — Echovideo extractor (main provider used by Aniwaves)
      playwright-extractor.ts — Playwright fallback (headless Chrome) for bot-protected pages
      vidplay.ts      — Vidplay extractor (unused currently — Aniwaves maps to Echovideo)
      megacloud.ts    — MegaCloud extractor (unused currently)
```

## API Endpoints

All routes are under `/api`:

| Endpoint | Params | Description |
|---|---|---|
| `GET /api/healthz` | — | Liveness check |
| `GET /api/search` | `q` | Search anime by keyword |
| `GET /api/details` | `id` | Anime metadata (title, genres, episode count, etc.) |
| `GET /api/episodes` | `id` | Full episode list with filler flags |
| `GET /api/servers` | `id`, `ep`, `type` (sub/dub) | Available streaming servers for an episode |
| `GET /api/stream` | `id`, `ep`, `type`, `server?` | Direct m3u8 URL + skip times + subtitle tracks |

### Stream response shape

```json
{
  "type": "direct",
  "provider": "echovideo",
  "m3u8": "https://cdn.example.com/anime/1/master.m3u8",
  "subtitles": [],
  "thumbnails": "https://cdn.example.com/thumbnails/abc.vtt",
  "intro": { "start": 0, "end": 90 },
  "outro": { "start": 1280, "end": 1369 }
}
```

## Architecture decisions

- **Contract-first**: The route layer validates all inputs with simple inline checks and delegates to `scraper.ts` + provider extractors. No ORM, no DB — purely stateless.
- **Echovideo getSources API**: Discovered by running the embed page's 164 KB obfuscated JS in a Node.js VM sandbox with mocked browser APIs. The correct endpoint is `/{embedPrefix}/getSources?id={encodedId}` with `Sec-Fetch-*: same-origin` headers. The `sources` field is a plain m3u8 URL string (not an array, not encrypted).
- **Playwright fallback**: `playwright-extractor.ts` launches headless Chromium as a last resort for pages that can't be solved with HTTP requests. Kept but rarely triggered once the correct Echovideo API path is known.
- **7-stage logging**: Each extraction stage is logged `[Provider S1] … [Provider S7]` for easy debugging of which stage fails in production.
- **Caching**: Episode lists, details, and servers are cached with 5-minute TTLs. Stream URLs are NOT cached (they are time-scoped tokens from Aniwaves).

## Gotchas

- The Echovideo embed URL is short-lived (generated per-session by Aniwaves). Do not cache stream results.
- The m3u8 CDN (`hlsxst1.burntburst45.store` etc.) is Cloudflare-protected. Clients playing the stream must send the correct `Referer` header or use the URL within a browser context.
- Playwright (headless Chromium) is external to the bundle (`playwright-core` is in esbuild `external[]`). It resolves from the workspace `node_modules` at runtime.
- Chromium binary path is hardcoded to the Nix store path: `/nix/store/0n9rl5l9syy808xi9bk4f6dhnfrvhkww-playwright-browsers-chromium/chromium-1080/chrome-linux/chrome`. Override with `CHROMIUM_PATH` env var.
- Never use `console.log` in server code — use `req.log` in route handlers, `logger` singleton elsewhere.
- Do not run `pnpm dev` at workspace root — use the workflow instead.

## User preferences

- Verbose (7-stage) logging for all extraction pipelines
- No iframe/embed fallbacks — stream endpoint must return a direct m3u8 URL or a 502 error
