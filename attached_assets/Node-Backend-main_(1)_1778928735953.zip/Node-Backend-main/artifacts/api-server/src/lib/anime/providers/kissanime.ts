/**
 * KissAnime (kissanime.com.ru) scraper — fallback source
 *
 * Discovered endpoints:
 *   Search:  POST /Search/SearchSuggest   body: type=Anime&keyword={q}
 *            → HTML <a class="item_search_link" href="/Anime/{slug}.{id}/">
 *   Details: GET /Anime/{slug}.{id}/
 *            → HTML page with title, genres, episode list links
 *   Episode: GET /Anime/{slug}.{id}/Episode-{num}?id={epId}
 *            → HTML page with video iframe (Cloudflare-protected)
 *
 * NOTE: Episode video sources are behind Cloudflare JavaScript challenge.
 * We can scrape search + details + episode list, but cannot extract video
 * sources without a headless browser. This source is used as a fallback
 * for metadata enrichment and episode discovery only.
 */
import axios from "axios";
import * as cheerio from "cheerio";
import { logger } from "../../logger.js";
import { cacheGet, cacheSet } from "../cache.js";
import type { AnimeSearchResult, AnimeDetails, Episode } from "../types.js";

const BASE_URL = "https://kissanime.com.ru";
const STATIC_URL = "https://static.anmedm.com";

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    Referer: BASE_URL,
  },
});

// ── Search ────────────────────────────────────────────────────────────────────

export async function searchKissanime(q: string): Promise<AnimeSearchResult[]> {
  const cacheKey = `kissanime:search:${q}`;
  const cached = cacheGet<AnimeSearchResult[]>(cacheKey);
  if (cached) return cached;

  logger.info({ q }, "[KissAnime] searching via /Search/SearchSuggest");

  try {
    const resp = await client.post(
      "/Search/SearchSuggest",
      new URLSearchParams({ type: "Anime", keyword: q }).toString(),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "X-Requested-With": "XMLHttpRequest",
        },
      }
    );

    const html = resp.data as string;
    const $ = cheerio.load(html);
    const results: AnimeSearchResult[] = [];

    $("a.item_search_link").each((_, el) => {
      const $el = $(el);
      const href = $el.attr("href") ?? "";
      // href = https://kissanime.com.ru/Anime/{slug}.{numericId}/
      const idMatch = href.match(/\/Anime\/([^/]+\.[\d]+)\//);
      if (!idMatch) return;
      const id = `ka:${idMatch[1]}`; // prefix to distinguish from Aniwaves IDs
      const title = $el.text().replace(/<[^>]*>/g, "").trim();
      const poster = $el.find("img.search_suggest_img").attr("src") ?? "";

      if (id && title) {
        results.push({
          id,
          title,
          poster: poster || `${STATIC_URL}/images/poster-placeholder.jpg`,
          type: "TV",
          episodes: { sub: 0, dub: 0 },
        });
      }
    });

    logger.info({ q, count: results.length }, "[KissAnime] search complete");
    cacheSet(cacheKey, results, 300);
    return results;
  } catch (err) {
    logger.warn({ error: (err as Error).message, q }, "[KissAnime] search failed");
    return [];
  }
}

// ── Details ───────────────────────────────────────────────────────────────────

export async function getKissanimeDetails(kaId: string): Promise<AnimeDetails | null> {
  // kaId = "ka:{slug}.{numericId}"
  const slug = kaId.replace(/^ka:/, "");
  const cacheKey = `kissanime:details:${kaId}`;
  const cached = cacheGet<AnimeDetails>(cacheKey);
  if (cached) return cached;

  logger.info({ kaId, slug }, "[KissAnime] fetching details");

  try {
    const resp = await client.get(`/Anime/${slug}/`);
    const html = resp.data as string;
    const $ = cheerio.load(html);

    const title =
      $("a.bigChar").first().text().trim() ||
      $("h1").first().text().trim() ||
      slug.split(".")[0].replace(/-/g, " ");

    const poster =
      $(".leftBox .thumb_in_cat img").attr("src") ||
      $("img.imgposter").attr("src") ||
      "";

    const description =
      $(".summary").text().trim() ||
      $(".description").text().trim() ||
      "";

    const genres: string[] = [];
    $("a[href*='/Genre/']").each((_, el) => {
      const g = $(el).text().trim();
      if (g) genres.push(g);
    });

    // Episode count from episode links
    const episodeLinks = $("a[href*='/Episode-']");
    const totalCount = episodeLinks.length;

    // Status/aired from info table
    let status = "Unknown";
    let aired = "Unknown";
    $(".barContent").find("p").each((_, el) => {
      const text = $(el).text().trim();
      if (text.toLowerCase().includes("status:")) {
        status = text.replace(/status:/i, "").trim();
      }
      if (text.toLowerCase().includes("date aired:") || text.toLowerCase().includes("aired:")) {
        aired = text.replace(/date aired:|aired:/i, "").trim();
      }
    });

    const details: AnimeDetails = {
      id: kaId,
      title,
      poster,
      description,
      type: "TV",
      status,
      aired,
      genres,
      episodes: { sub: totalCount, dub: 0, total: totalCount },
    };

    cacheSet(cacheKey, details, 1800);
    logger.info({ kaId, title, totalCount }, "[KissAnime] details fetched");
    return details;
  } catch (err) {
    logger.warn({ error: (err as Error).message, kaId }, "[KissAnime] details failed");
    return null;
  }
}

// ── Episodes ──────────────────────────────────────────────────────────────────

export async function getKissanimeEpisodes(kaId: string): Promise<Episode[]> {
  const slug = kaId.replace(/^ka:/, "");
  const cacheKey = `kissanime:episodes:${kaId}`;
  const cached = cacheGet<Episode[]>(cacheKey);
  if (cached) return cached;

  logger.info({ kaId, slug }, "[KissAnime] fetching episode list");

  try {
    const resp = await client.get(`/Anime/${slug}/`);
    const html = resp.data as string;
    const $ = cheerio.load(html);

    const episodes: Episode[] = [];

    // Episode links: <a href="/Anime/{slug}/Episode-001?id=12345">Episode 1</a>
    $("a[href*='/Episode-']").each((_, el) => {
      const $el = $(el);
      const href = $el.attr("href") ?? "";
      const epMatch = href.match(/Episode-0*(\d+)\?id=(\d+)/);
      if (!epMatch) return;

      const num = parseInt(epMatch[1], 10);
      const epId = epMatch[2];
      const title = $el.attr("title") || null;

      if (num > 0 && epId) {
        episodes.push({
          number: num,
          id: `ka_ep:${slug}/Episode-${String(num).padStart(3, "0")}?id=${epId}`,
          title,
          isFiller: false,
        });
      }
    });

    episodes.sort((a, b) => a.number - b.number);
    cacheSet(cacheKey, episodes, 600);
    logger.info({ kaId, count: episodes.length }, "[KissAnime] episodes fetched");
    return episodes;
  } catch (err) {
    logger.warn({ error: (err as Error).message, kaId }, "[KissAnime] episodes failed");
    return [];
  }
}
