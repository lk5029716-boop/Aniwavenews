import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useSearchAnime, getSearchAnimeQueryKey } from "@workspace/api-client-react";
import { AnimeCard } from "@/components/anime/AnimeCard";
import { AnimeCardSkeleton } from "@/components/anime/AnimeCardSkeleton";
import { Search, SearchX } from "lucide-react";

export default function SearchPage() {
  const [location, navigate] = useLocation();
  const urlParams = new URLSearchParams(location.includes("?") ? location.split("?")[1] : "");
  const q = urlParams.get("q") ?? "";

  const [inputVal, setInputVal] = useState(q);

  const { data, isLoading, isFetching } = useSearchAnime(
    { q },
    { query: { enabled: q.length > 0, queryKey: getSearchAnimeQueryKey({ q }), staleTime: 300_000 } }
  );

  const results = data?.results ?? [];

  useEffect(() => { setInputVal(q); }, [q]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (inputVal.trim()) navigate(`/search?q=${encodeURIComponent(inputVal.trim())}`);
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-8">
      {/* Search bar */}
      <form onSubmit={handleSearch} className="mb-8 flex gap-2">
        <div className="relative flex-1 max-w-xl">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder="Search anime title..."
            className="h-10 w-full rounded-xl border border-border bg-card pl-9 pr-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            data-testid="search-input"
            autoFocus
          />
        </div>
        <button
          type="submit"
          className="h-10 rounded-xl bg-primary px-5 font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
          data-testid="search-submit-button"
        >
          Search
        </button>
      </form>

      {/* Results heading */}
      {q && (
        <div className="mb-4 flex items-center gap-2">
          <h1 className="font-serif text-xl font-semibold text-foreground">
            Results for &quot;{q}&quot;
          </h1>
          {(isLoading || isFetching) && (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          )}
          {!isLoading && !isFetching && (
            <span className="text-sm text-muted-foreground">
              ({results.length} found)
            </span>
          )}
        </div>
      )}

      {/* Loading skeletons */}
      {isLoading && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {Array.from({ length: 10 }).map((_, i) => <AnimeCardSkeleton key={i} />)}
        </div>
      )}

      {/* Results */}
      {!isLoading && results.length > 0 && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {results.map((anime) => (
            <AnimeCard key={anime.id} anime={anime} />
          ))}
        </div>
      )}

      {/* Empty state */}
      {!isLoading && q && results.length === 0 && (
        <div className="flex flex-col items-center gap-4 py-20 text-muted-foreground">
          <SearchX className="h-12 w-12" />
          <p className="text-lg">No results for &quot;{q}&quot;</p>
          <p className="text-sm">Try a different keyword or check the spelling</p>
        </div>
      )}

      {/* Prompt when no query */}
      {!q && (
        <div className="flex flex-col items-center gap-4 py-20 text-muted-foreground">
          <Search className="h-12 w-12" />
          <p className="text-lg">Type something to search</p>
        </div>
      )}
    </main>
  );
}
