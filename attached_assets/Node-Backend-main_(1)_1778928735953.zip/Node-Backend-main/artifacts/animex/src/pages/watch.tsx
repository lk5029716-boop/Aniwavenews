import { useEffect, useState, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { ChevronLeft, ChevronRight, AlertCircle, RefreshCw, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  useGetAnimeDetails,
  useGetEpisodes,
  useGetServers,
  useGetStream,
  getGetAnimeDetailsQueryKey,
  getGetEpisodesQueryKey,
  getGetServersQueryKey,
  getGetStreamQueryKey,
} from "@workspace/api-client-react";
import { HlsPlayer } from "@/components/player/HlsPlayer";
import type { StreamSource } from "@workspace/api-client-react";

export default function WatchPage() {
  const params = useParams<{ id: string }>();
  const id = params.id ?? "";
  const [location, navigate] = useLocation();
  const urlSearchStr = location.includes("?") ? (location.split("?")[1] ?? "") : "";
  const urlParams = new URLSearchParams(urlSearchStr);
  const epNum = parseInt(urlParams.get("ep") ?? "1", 10);
  const typeParam = (urlParams.get("type") ?? "sub") as "sub" | "dub" | "raw";

  // Track which servers have failed so we skip them on retry
  const [failedServers, setFailedServers] = useState<Set<string>>(new Set());
  const [allFailed, setAllFailed] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // Reset on episode change
  const prevKeyRef = useRef("");
  const key = `${id}:${epNum}:${typeParam}`;
  if (prevKeyRef.current !== key) {
    prevKeyRef.current = key;
    if (failedServers.size > 0) setFailedServers(new Set());
    if (allFailed) setAllFailed(false);
  }

  // Details
  const { data: details } = useGetAnimeDetails(
    { id },
    { query: { enabled: !!id, queryKey: getGetAnimeDetailsQueryKey({ id }), staleTime: 1_800_000 } }
  );

  // Episodes
  const { data: episodesData } = useGetEpisodes(
    { id },
    { query: { enabled: !!id, queryKey: getGetEpisodesQueryKey({ id }), staleTime: 600_000 } }
  );
  const episodes = episodesData?.episodes ?? [];

  // Servers — get them but never show to user
  const { data: serversData, isLoading: serversLoading } = useGetServers(
    { id, ep: epNum, type: typeParam },
    {
      query: {
        enabled: !!id && epNum > 0,
        queryKey: getGetServersQueryKey({ id, ep: epNum, type: typeParam }),
        staleTime: 300_000,
      },
    }
  );
  const servers = serversData?.servers ?? [];

  // Pick the first server that hasn't failed
  const activeServer = servers.find((s) => !failedServers.has(s.name))?.name ?? servers[0]?.name ?? undefined;

  const streamParams = {
    id,
    ep: epNum,
    type: typeParam,
    ...(activeServer ? { server: activeServer } : {}),
  };

  const {
    data: streamData,
    isLoading: streamLoading,
    isError: streamIsError,
  } = useGetStream(streamParams, {
    query: {
      enabled: !!id && epNum > 0 && servers.length > 0 && !allFailed,
      queryKey: [...getGetStreamQueryKey(streamParams), retryCount],
      staleTime: 120_000,
      retry: false,
    },
  });

  const stream = streamData as (StreamSource & { _server?: string; _failedServers?: string[] }) | undefined;

  // When API-level failure happens, try next server automatically
  useEffect(() => {
    if (!streamIsError || !activeServer) return;
    tryNextServer(activeServer);
  }, [streamIsError]);

  // Reflect backend's reported failed servers
  useEffect(() => {
    if (stream?._failedServers?.length) {
      setFailedServers((prev) => new Set([...prev, ...stream._failedServers!]));
    }
  }, [stream]);

  function tryNextServer(failedName: string) {
    const updated = new Set([...failedServers, failedName]);
    const next = servers.find((s) => !updated.has(s.name));
    if (next) {
      toast.error(`Server failed — trying another automatically`);
      setFailedServers(updated);
      setRetryCount((n) => n + 1);
    } else {
      setFailedServers(updated);
      setAllFailed(true);
    }
  }

  // HLS-level error (CDN block etc.)
  function handlePlayerError() {
    if (activeServer) tryNextServer(activeServer);
  }

  // Save continue-watching
  useEffect(() => {
    if (!details || !stream?.m3u8) return;
    const list = JSON.parse(localStorage.getItem("animeX_continue_watching") ?? "[]") as Array<{
      id: string; ep: number; type: string; title: string; pos: number; poster: string;
    }>;
    const filtered = list.filter((x) => !(x.id === id && x.ep === epNum));
    filtered.unshift({ id, ep: epNum, type: typeParam, title: details.title, pos: 0, poster: details.poster });
    localStorage.setItem("animeX_continue_watching", JSON.stringify(filtered.slice(0, 20)));
  }, [details, stream?.m3u8]);

  function proxiedM3u8(m3u8: string) {
    const base = localStorage.getItem("animeX_api_base") ?? "";
    return `${base}/api/proxy?url=${encodeURIComponent(m3u8)}&referer=${encodeURIComponent("https://play.echovideo.ru/")}`;
  }

  const prevEp = episodes.find((e) => e.number === epNum - 1);
  const nextEp = episodes.find((e) => e.number === epNum + 1);
  function navTo(ep: number) {
    navigate(`/watch/${encodeURIComponent(id)}?ep=${ep}&type=${typeParam}`);
  }

  const isLoading = serversLoading || (streamLoading && !allFailed);
  const progressKey = `${id}_${epNum}_${typeParam}`;

  return (
    <main className="mx-auto max-w-7xl px-4 py-6">
      <div className="flex flex-col gap-6 lg:flex-row">

        {/* ── Left: player ── */}
        <div className="flex-1 min-w-0">

          {/* Breadcrumb */}
          <div className="mb-3 flex items-center gap-2 text-sm text-muted-foreground">
            <button
              onClick={() => navigate(`/anime/${encodeURIComponent(id)}`)}
              className="hover:text-foreground transition-colors"
            >
              {details?.title ?? id}
            </button>
            <span>/</span>
            <span className="text-foreground">
              Episode {epNum}{typeParam === "dub" ? " (Dub)" : ""}
            </span>
          </div>

          {/* Player area */}
          {allFailed ? (
            <div className="flex aspect-video w-full flex-col items-center justify-center gap-4 rounded-xl border border-border bg-card">
              <AlertCircle className="h-10 w-10 text-destructive" />
              <p className="text-muted-foreground text-sm">Could not load this episode.</p>
              <button
                onClick={() => { setFailedServers(new Set()); setAllFailed(false); setRetryCount((n) => n + 1); }}
                className="flex items-center gap-2 rounded-lg bg-secondary px-4 py-2 text-sm font-medium hover:bg-border transition-colors"
                data-testid="retry-btn"
              >
                <RefreshCw className="h-4 w-4" />
                Retry
              </button>
            </div>
          ) : isLoading ? (
            <div className="flex aspect-video w-full flex-col items-center justify-center gap-3 rounded-xl border border-border bg-card text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="text-sm">Loading episode...</span>
            </div>
          ) : stream?.m3u8 ? (
            <HlsPlayer
              src={proxiedM3u8(stream.m3u8)}
              subtitles={stream.subtitles}
              intro={stream.intro}
              outro={stream.outro}
              progressKey={progressKey}
              onError={handlePlayerError}
            />
          ) : (
            <div className="flex aspect-video w-full items-center justify-center rounded-xl border border-border bg-card">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}

          {/* Prev / Next */}
          <div className="mt-4 flex items-center justify-between">
            <button
              onClick={() => prevEp && navTo(prevEp.number)}
              disabled={!prevEp}
              className="flex items-center gap-2 rounded-lg border border-border bg-secondary px-4 py-2 text-sm font-medium hover:border-primary/60 hover:text-primary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              data-testid="prev-ep-btn"
            >
              <ChevronLeft className="h-4 w-4" /> Previous
            </button>
            <span className="text-sm text-muted-foreground">EP {epNum}</span>
            <button
              onClick={() => nextEp && navTo(nextEp.number)}
              disabled={!nextEp}
              className="flex items-center gap-2 rounded-lg border border-border bg-secondary px-4 py-2 text-sm font-medium hover:border-primary/60 hover:text-primary disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              data-testid="next-ep-btn"
            >
              Next <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* ── Right: episode sidebar ── */}
        <aside className="w-full lg:w-72 xl:w-80 shrink-0">
          <div className="rounded-xl border border-border bg-card">
            <div className="border-b border-border p-3 flex items-center justify-between">
              <h2 className="font-serif font-semibold text-foreground">Episodes</h2>
              {episodes.length > 0 && (
                <span className="text-xs text-muted-foreground">{episodes.length} total</span>
              )}
            </div>
            <div className="max-h-[72vh] overflow-y-auto p-2">
              {episodes.length === 0 ? (
                <div className="py-8 text-center text-sm text-muted-foreground">
                  <Loader2 className="mx-auto mb-2 h-5 w-5 animate-spin" />
                  Loading...
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-1.5">
                  {episodes.map((ep) => (
                    <button
                      key={ep.id}
                      onClick={() => navTo(ep.number)}
                      title={ep.title ?? `Episode ${ep.number}`}
                      className={`flex h-9 items-center justify-center rounded-lg text-xs font-medium transition-colors ${
                        ep.number === epNum
                          ? "bg-primary text-primary-foreground"
                          : ep.isFiller
                          ? "border border-yellow-500/20 bg-yellow-500/5 text-yellow-500/70 hover:bg-yellow-500/10"
                          : "border border-border bg-secondary/60 text-muted-foreground hover:border-primary/50 hover:text-foreground"
                      }`}
                      data-testid={`sidebar-ep-${ep.number}`}
                    >
                      {ep.number}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
