import { useLocation } from "wouter";
import { useState } from "react";
import { Search, Play } from "lucide-react";
import { useSearchAnime, getSearchAnimeQueryKey } from "@workspace/api-client-react";
import { AnimeCard } from "@/components/anime/AnimeCard";
import { AnimeCardSkeleton } from "@/components/anime/AnimeCardSkeleton";
import type { AnimeSearchResult } from "@workspace/api-client-react";

const FEATURED_TERMS = ["one piece", "naruto", "bleach", "demon slayer"];

function getStoredProgress(): Array<{ id: string; ep: number; type: string; title: string; pos: number; poster: string }> {
  try {
    const raw = localStorage.getItem("animeX_continue_watching");
    return raw ? (JSON.parse(raw) as Array<{ id: string; ep: number; type: string; title: string; pos: number; poster: string }>) : [];
  } catch {
    return [];
  }
}

export default function Home() {
  const [, navigate] = useLocation();
  const [query, setQuery] = useState("");
  const [searchTerm] = useState(
    () => FEATURED_TERMS[Math.floor(Math.random() * FEATURED_TERMS.length)] ?? "naruto"
  );

  const { data, isLoading } = useSearchAnime(
    { q: searchTerm },
    { query: { queryKey: getSearchAnimeQueryKey({ q: searchTerm }), staleTime: 300_000 } }
  );
  const results: AnimeSearchResult[] = data?.results ?? [];
  const continueWatching = getStoredProgress();

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  }

  return (
    <main className="mx-auto max-w-7xl px-4 py-8">
      {/* Hero */}
      <section className="mb-12 text-center">
        <h1 className="mb-3 font-serif text-5xl font-bold tracking-tight text-foreground">
          Watch <span className="text-primary">Anime</span> Free
        </h1>
        <p className="mb-8 text-muted-foreground">
          Stream thousands of anime episodes in HD — sub and dub available
        </p>
        <form
          onSubmit={handleSearch}
          className="mx-auto flex max-w-lg gap-2"
        >
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search anime title..."
              className="h-11 w-full rounded-xl border border-border bg-card pl-9 pr-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              data-testid="hero-search-input"
            />
          </div>
          <button
            type="submit"
            className="h-11 rounded-xl bg-primary px-6 font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
            data-testid="hero-search-button"
          >
            Search
          </button>
        </form>
      </section>

      {/* Continue watching */}
      {continueWatching.length > 0 && (
        <section className="mb-10">
          <h2 className="mb-4 font-serif text-xl font-semibold text-foreground">
            Continue Watching
          </h2>
          <div className="flex gap-4 overflow-x-auto pb-2">
            {continueWatching.slice(0, 8).map((item) => (
              <button
                key={`${item.id}-${item.ep}`}
                onClick={() =>
                  navigate(`/watch/${encodeURIComponent(item.id)}?ep=${item.ep}&type=${item.type}`)
                }
                className="group relative flex w-40 shrink-0 flex-col overflow-hidden rounded-xl border border-border bg-card hover:border-primary/60 transition-colors focus:outline-none"
                data-testid={`continue-watching-${item.id}`}
              >
                <div className="relative aspect-video overflow-hidden bg-secondary">
                  {item.poster ? (
                    <img
                      src={item.poster}
                      alt={item.title}
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center">
                      <Play className="h-6 w-6 text-muted-foreground" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="h-8 w-8 text-white" />
                  </div>
                </div>
                <div className="p-2">
                  <p className="line-clamp-1 text-xs font-medium text-foreground">{item.title}</p>
                  <p className="text-xs text-muted-foreground">EP {item.ep}</p>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Discovery */}
      <section>
        <h2 className="mb-4 font-serif text-xl font-semibold capitalize text-foreground">
          {isLoading ? "Loading..." : `Popular: ${searchTerm}`}
        </h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {isLoading
            ? Array.from({ length: 12 }).map((_, i) => <AnimeCardSkeleton key={i} />)
            : results.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
        </div>
      </section>
    </main>
  );
}
