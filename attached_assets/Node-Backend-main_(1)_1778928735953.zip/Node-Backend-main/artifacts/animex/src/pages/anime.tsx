import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { Play, ChevronLeft, Star } from "lucide-react";
import {
  useGetAnimeDetails,
  useGetEpisodes,
  getGetAnimeDetailsQueryKey,
  getGetEpisodesQueryKey,
} from "@workspace/api-client-react";

export default function AnimePage() {
  const params = useParams<{ id: string }>();
  const id = params.id ?? "";
  const [, navigate] = useLocation();
  const [epType, setEpType] = useState<"sub" | "dub">("sub");

  const { data: details, isLoading: detailsLoading, isError: detailsError } = useGetAnimeDetails(
    { id },
    { query: { enabled: !!id, queryKey: getGetAnimeDetailsQueryKey({ id }), staleTime: 1_800_000 } }
  );

  const { data: episodesData, isLoading: epsLoading } = useGetEpisodes(
    { id },
    { query: { enabled: !!id, queryKey: getGetEpisodesQueryKey({ id }), staleTime: 600_000 } }
  );

  const episodes = episodesData?.episodes ?? [];

  function watchEp(epNumber: number) {
    navigate(`/watch/${encodeURIComponent(id)}?ep=${epNumber}&type=${epType}`);
  }

  if (detailsLoading) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="animate-pulse">
          <div className="mb-6 h-8 w-48 rounded bg-secondary" />
          <div className="flex gap-6">
            <div className="h-72 w-48 shrink-0 rounded-xl bg-secondary" />
            <div className="flex-1 space-y-3">
              <div className="h-8 w-3/4 rounded bg-secondary" />
              <div className="h-4 w-1/2 rounded bg-secondary" />
              <div className="h-4 w-full rounded bg-secondary" />
              <div className="h-4 w-5/6 rounded bg-secondary" />
            </div>
          </div>
        </div>
      </main>
    );
  }

  if (detailsError || !details) {
    return (
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="flex flex-col items-center gap-4 py-20 text-muted-foreground">
          <p className="text-lg">Could not load anime details</p>
          <button
            onClick={() => navigate("/")}
            className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
          >
            Back to home
          </button>
        </div>
      </main>
    );
  }

  const hasDub = details.episodes.dub > 0;

  return (
    <main className="mx-auto max-w-7xl px-4 py-8">
      <button
        onClick={() => navigate("/")}
        className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ChevronLeft className="h-4 w-4" />
        Back
      </button>

      {/* Details header */}
      <div className="mb-8 flex flex-col gap-6 md:flex-row">
        {/* Poster */}
        <div className="shrink-0">
          <div className="h-72 w-48 overflow-hidden rounded-xl bg-secondary shadow-xl md:h-80 md:w-52">
            {details.poster ? (
              <img
                src={details.poster}
                alt={details.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground text-sm">
                No image
              </div>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col gap-4">
          <div>
            <h1 className="mb-2 font-serif text-3xl font-bold text-foreground leading-tight">
              {details.title}
            </h1>
            <div className="flex flex-wrap gap-2 text-sm">
              {details.type && (
                <span className="rounded-md border border-border bg-secondary px-2.5 py-1">
                  {details.type}
                </span>
              )}
              {details.status && details.status !== "Unknown" && (
                <span className="rounded-md border border-border bg-secondary px-2.5 py-1">
                  {details.status}
                </span>
              )}
              {details.aired && details.aired !== "Unknown" && (
                <span className="rounded-md border border-border bg-secondary px-2.5 py-1">
                  {details.aired}
                </span>
              )}
              {details.episodes.total > 0 && (
                <span className="rounded-md border border-primary/30 bg-primary/10 px-2.5 py-1 text-primary">
                  {details.episodes.total} eps
                </span>
              )}
            </div>
          </div>

          {details.genres.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {details.genres.map((g) => (
                <span
                  key={g}
                  className="rounded-full border border-border bg-secondary px-3 py-0.5 text-xs text-muted-foreground"
                >
                  {g}
                </span>
              ))}
            </div>
          )}

          {details.description && (
            <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground line-clamp-5">
              {details.description}
            </p>
          )}

          {episodes.length > 0 && (
            <button
              onClick={() => watchEp(1)}
              className="mt-2 flex w-fit items-center gap-2 rounded-xl bg-primary px-6 py-2.5 font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
              data-testid="watch-first-button"
            >
              <Play className="h-4 w-4" />
              Watch Episode 1
            </button>
          )}
        </div>
      </div>

      {/* Episodes */}
      <section>
        <div className="mb-4 flex items-center gap-4">
          <h2 className="font-serif text-xl font-semibold text-foreground">
            Episodes
            {!epsLoading && episodes.length > 0 && (
              <span className="ml-2 text-sm font-normal text-muted-foreground">
                ({episodes.length})
              </span>
            )}
          </h2>
          {hasDub && (
            <div className="flex rounded-lg border border-border bg-secondary p-0.5">
              {(["sub", "dub"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setEpType(t)}
                  className={`rounded-md px-3 py-1 text-sm font-medium transition-colors uppercase ${epType === t ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
                  data-testid={`type-tab-${t}`}
                >
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>

        {epsLoading && (
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 xl:grid-cols-12">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="h-10 animate-pulse rounded-lg bg-secondary" />
            ))}
          </div>
        )}

        {!epsLoading && episodes.length === 0 && (
          <p className="text-muted-foreground">No episodes found.</p>
        )}

        {!epsLoading && episodes.length > 0 && (
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 xl:grid-cols-12">
            {episodes.map((ep) => (
              <button
                key={ep.id}
                onClick={() => watchEp(ep.number)}
                className={`flex h-10 items-center justify-center rounded-lg border text-sm font-medium transition-colors hover:border-primary/60 hover:bg-primary/10 hover:text-primary focus:outline-none focus:ring-2 focus:ring-primary ${ep.isFiller ? "border-yellow-500/30 bg-yellow-500/5 text-yellow-500/70" : "border-border bg-secondary text-foreground"}`}
                title={ep.title ?? `Episode ${ep.number}`}
                data-testid={`ep-button-${ep.number}`}
              >
                {ep.isFiller && <Star className="mr-1 h-3 w-3" />}
                {ep.number}
              </button>
            ))}
          </div>
        )}
        {!epsLoading && episodes.some((e) => e.isFiller) && (
          <p className="mt-2 text-xs text-muted-foreground">
            <Star className="mr-1 inline h-3 w-3 text-yellow-500/70" />
            Filler episodes highlighted in yellow
          </p>
        )}
      </section>
    </main>
  );
}
