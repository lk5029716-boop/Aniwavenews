import { useEffect, useRef, useState, useCallback } from "react";
import Hls from "hls.js";
import { Play, Pause, Maximize, Volume2, VolumeX, Subtitles } from "lucide-react";
import type { SkipTime, Subtitle } from "@workspace/api-client-react";

interface Props {
  src: string;
  subtitles?: Subtitle[];
  intro?: SkipTime | null;
  outro?: SkipTime | null;
  progressKey?: string;
  onError?: () => void;
}

function formatTime(s: number) {
  if (!isFinite(s) || isNaN(s)) return "0:00";
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export function HlsPlayer({ src, subtitles, intro, outro, progressKey, onError }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const prevSrcRef = useRef<string>("");
  const saveTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [skipInfo, setSkipInfo] = useState<"intro" | "outro" | null>(null);
  const [activeSub, setActiveSub] = useState<string | null>(null);
  const [showSubMenu, setShowSubMenu] = useState(false);
  const [buffered, setBuffered] = useState(0);
  const [resumed, setResumed] = useState(false);

  // Load HLS only when src actually changes
  useEffect(() => {
    if (!src || src === prevSrcRef.current) return;
    prevSrcRef.current = src;

    const video = videoRef.current;
    if (!video) return;

    // Clean up previous instance
    hlsRef.current?.destroy();
    hlsRef.current = null;

    if (Hls.isSupported()) {
      const hls = new Hls({ startLevel: -1 });
      hlsRef.current = hls;
      hls.loadSource(src);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => {/* user hasn't interacted yet */});
      });
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) onError?.();
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = src;
      video.play().catch(() => {});
    } else {
      onError?.();
      return;
    }

    // Restore saved position after metadata loads
    setResumed(false);
    const onMeta = () => {
      if (progressKey && !resumed) {
        const saved = parseFloat(localStorage.getItem(`animeX_progress_${progressKey}`) ?? "0");
        if (saved > 10 && isFinite(saved)) {
          video.currentTime = saved;
          setResumed(true);
        }
      }
    };
    video.addEventListener("loadedmetadata", onMeta, { once: true });

    return () => {
      video.removeEventListener("loadedmetadata", onMeta);
    };
  }, [src]);

  // Cleanup HLS on unmount
  useEffect(() => {
    return () => {
      hlsRef.current?.destroy();
      if (saveTimerRef.current) clearInterval(saveTimerRef.current);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, []);

  // Save progress periodically
  useEffect(() => {
    if (!progressKey) return;
    if (saveTimerRef.current) clearInterval(saveTimerRef.current);
    saveTimerRef.current = setInterval(() => {
      const v = videoRef.current;
      if (v && v.currentTime > 5) {
        localStorage.setItem(`animeX_progress_${progressKey}`, String(v.currentTime));
      }
    }, 5000);
    return () => { if (saveTimerRef.current) clearInterval(saveTimerRef.current); };
  }, [progressKey]);

  // Video event listeners
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onDuration = () => setDuration(video.duration);
    const onTime = () => {
      setCurrentTime(video.currentTime);
      if (video.buffered.length > 0 && video.duration > 0) {
        setBuffered((video.buffered.end(video.buffered.length - 1) / video.duration) * 100);
      }
      if (intro && video.currentTime >= intro.start && video.currentTime < intro.end) {
        setSkipInfo("intro");
      } else if (outro && video.currentTime >= outro.start && video.currentTime < outro.end) {
        setSkipInfo("outro");
      } else {
        setSkipInfo(null);
      }
    };

    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("durationchange", onDuration);
    video.addEventListener("timeupdate", onTime);
    return () => {
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("durationchange", onDuration);
      video.removeEventListener("timeupdate", onTime);
    };
  }, [intro, outro]);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === "INPUT") return;
      const v = videoRef.current;
      if (!v) return;
      if (e.key === " ") { e.preventDefault(); v.paused ? v.play() : v.pause(); }
      if (e.key === "f" || e.key === "F") { e.preventDefault(); toggleFullscreen(); }
      if (e.key === "ArrowLeft") { e.preventDefault(); v.currentTime = Math.max(0, v.currentTime - 10); }
      if (e.key === "ArrowRight") { e.preventDefault(); v.currentTime = Math.min(v.duration, v.currentTime + 10); }
      if (e.key === "m" || e.key === "M") { e.preventDefault(); v.muted = !v.muted; setMuted(v.muted); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen();
  }, []);

  function showControlsFor() {
    setShowControls(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => setShowControls(false), 3000);
  }

  function togglePlay() {
    const v = videoRef.current;
    if (!v) return;
    v.paused ? v.play() : v.pause();
  }

  function seek(e: React.MouseEvent<HTMLDivElement>) {
    const v = videoRef.current;
    if (!v || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    v.currentTime = ((e.clientX - rect.left) / rect.width) * duration;
  }

  function skip(type: "intro" | "outro") {
    const v = videoRef.current;
    if (!v) return;
    const t = type === "intro" ? intro?.end : outro?.end;
    if (t != null) v.currentTime = t;
    setSkipInfo(null);
  }

  function setSubtitle(url: string | null) {
    const v = videoRef.current;
    if (!v) return;
    v.querySelectorAll("track").forEach((t) => t.remove());
    if (url) {
      const track = document.createElement("track");
      track.kind = "subtitles";
      track.src = url;
      track.default = true;
      v.appendChild(track);
      setTimeout(() => { if (v.textTracks[0]) v.textTracks[0].mode = "showing"; }, 100);
    }
    setActiveSub(url);
    setShowSubMenu(false);
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="group relative aspect-video w-full overflow-hidden rounded-xl bg-black select-none"
      onMouseMove={showControlsFor}
      onMouseLeave={() => playing && setShowControls(false)}
      onClick={togglePlay}
      data-testid="hls-player"
    >
      <video ref={videoRef} className="h-full w-full" crossOrigin="anonymous" playsInline />

      {/* Skip button */}
      {skipInfo && (
        <div className="absolute bottom-20 right-4 z-10">
          <button
            onClick={(e) => { e.stopPropagation(); skip(skipInfo); }}
            className="rounded-lg border border-primary/60 bg-background/80 px-4 py-2 text-sm font-semibold text-primary backdrop-blur-sm hover:bg-primary hover:text-primary-foreground transition-colors"
            data-testid={`skip-${skipInfo}-btn`}
          >
            Skip {skipInfo === "intro" ? "Intro" : "Outro"}
          </button>
        </div>
      )}

      {/* Controls */}
      <div
        className={`absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/80 via-black/20 to-transparent px-4 pb-3 pt-12 transition-opacity duration-200 ${showControls || !playing ? "opacity-100" : "opacity-0"}`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Seek bar */}
        <div
          className="relative mb-3 h-1.5 cursor-pointer rounded-full bg-white/20"
          onClick={seek}
          data-testid="seek-bar"
        >
          <div className="absolute h-full rounded-full bg-white/30" style={{ width: `${buffered}%` }} />
          <div className="absolute h-full rounded-full bg-primary" style={{ width: `${progress}%` }} />
        </div>

        <div className="flex items-center gap-3">
          <button onClick={togglePlay} className="rounded p-1.5 text-white hover:bg-white/10" data-testid="play-btn">
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </button>
          <button
            onClick={() => { const v = videoRef.current; if (!v) return; v.muted = !v.muted; setMuted(v.muted); }}
            className="rounded p-1.5 text-white hover:bg-white/10"
          >
            {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </button>
          <span className="ml-auto text-xs text-white/70">{formatTime(currentTime)} / {formatTime(duration)}</span>

          {subtitles && subtitles.length > 0 && (
            <div className="relative">
              <button
                onClick={() => setShowSubMenu((s) => !s)}
                className={`rounded p-1.5 hover:bg-white/10 ${activeSub ? "text-primary" : "text-white"}`}
                data-testid="subs-btn"
              >
                <Subtitles className="h-5 w-5" />
              </button>
              {showSubMenu && (
                <div className="absolute bottom-full right-0 mb-2 min-w-[140px] rounded-lg border border-border bg-card p-1 shadow-xl">
                  <button onClick={() => setSubtitle(null)} className={`block w-full rounded px-3 py-1.5 text-left text-xs hover:bg-secondary ${!activeSub ? "text-primary" : "text-foreground"}`}>Off</button>
                  {subtitles.map((s) => (
                    <button key={s.url} onClick={() => setSubtitle(s.url)} className={`block w-full rounded px-3 py-1.5 text-left text-xs hover:bg-secondary ${activeSub === s.url ? "text-primary" : "text-foreground"}`}>{s.label}</button>
                  ))}
                </div>
              )}
            </div>
          )}

          <button onClick={toggleFullscreen} className="rounded p-1.5 text-white hover:bg-white/10" data-testid="fullscreen-btn">
            <Maximize className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
