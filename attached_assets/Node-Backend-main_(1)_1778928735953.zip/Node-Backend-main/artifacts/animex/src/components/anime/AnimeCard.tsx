import { useLocation } from "wouter";
import type { AnimeSearchResult } from "@workspace/api-client-react";

interface Props {
  anime: AnimeSearchResult;
  progress?: { ep: number; pos: number } | null;
}

export function AnimeCard({ anime, progress }: Props) {
  const [, navigate] = useLocation();

  return (
    <button
      onClick={() => navigate(`/anime/${encodeURIComponent(anime.id)}`)}
      className="group relative flex flex-col overflow-hidden rounded-xl border border-border bg-card text-left transition-all hover:border-primary/60 hover:shadow-lg hover:shadow-primary/10 focus:outline-none focus:ring-2 focus:ring-primary"
      data-testid={`anime-card-${anime.id}`}
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-secondary">
        {anime.poster ? (
          <img
            src={anime.poster}
            alt={anime.title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-muted-foreground text-xs">
            No image
          </div>
        )}
        {progress && (
          <div
            className="absolute bottom-0 left-0 h-1 bg-primary"
            style={{ width: "40%" }}
          />
        )}
        <div className="absolute top-2 left-2">
          <span className="rounded-md bg-background/80 px-1.5 py-0.5 text-xs font-medium text-foreground backdrop-blur-sm">
            {anime.type || "TV"}
          </span>
        </div>
        {progress && (
          <div className="absolute top-2 right-2">
            <span className="rounded-md bg-primary/90 px-1.5 py-0.5 text-xs font-semibold text-primary-foreground">
              EP {progress.ep}
            </span>
          </div>
        )}
      </div>
      <div className="flex flex-col gap-1 p-3">
        <h3 className="line-clamp-2 text-sm font-semibold text-foreground leading-tight">
          {anime.title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {anime.episodes.sub > 0 && (
            <span>Sub: {anime.episodes.sub}</span>
          )}
          {anime.episodes.dub > 0 && (
            <span>Dub: {anime.episodes.dub}</span>
          )}
        </div>
      </div>
    </button>
  );
}
