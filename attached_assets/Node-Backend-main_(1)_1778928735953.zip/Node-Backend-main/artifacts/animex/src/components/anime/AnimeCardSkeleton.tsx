export function AnimeCardSkeleton() {
  return (
    <div className="flex flex-col overflow-hidden rounded-xl border border-border bg-card">
      <div className="aspect-[2/3] w-full animate-pulse bg-secondary" />
      <div className="flex flex-col gap-2 p-3">
        <div className="h-4 w-full animate-pulse rounded bg-secondary" />
        <div className="h-3 w-2/3 animate-pulse rounded bg-secondary" />
      </div>
    </div>
  );
}
