import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { Search, Settings, X } from "lucide-react";

export function Header() {
  const [, navigate] = useLocation();
  const [query, setQuery] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [apiBase, setApiBase] = useState(
    () => localStorage.getItem("animeX_api_base") ?? ""
  );
  const inputRef = useRef<HTMLInputElement>(null);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  }

  function saveApiBase() {
    localStorage.setItem("animeX_api_base", apiBase);
    setShowSettings(false);
    window.location.reload();
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "/" && document.activeElement?.tagName !== "INPUT") {
        e.preventDefault();
        inputRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-4 px-4">
          <button
            onClick={() => navigate("/")}
            className="shrink-0 font-serif text-xl font-bold tracking-wide text-primary"
          >
            AnimeX
          </button>

          <form onSubmit={handleSearch} className="flex flex-1 items-center gap-2">
            <div className="relative flex-1 max-w-md">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search anime... (/)"
                className="h-9 w-full rounded-lg border border-border bg-card pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                data-testid="header-search-input"
              />
            </div>
          </form>

          <button
            onClick={() => setShowSettings(true)}
            className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
            data-testid="settings-button"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </header>

      {showSettings && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-xl border border-border bg-card p-6 shadow-xl">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-serif text-lg font-semibold">Settings</h2>
              <button
                onClick={() => setShowSettings(false)}
                className="rounded p-1 hover:bg-secondary"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <label className="mb-1 block text-sm text-muted-foreground">
              API base URL
            </label>
            <input
              value={apiBase}
              onChange={(e) => setApiBase(e.target.value)}
              placeholder="Leave empty for default (/api)"
              className="mb-4 h-9 w-full rounded-lg border border-border bg-background px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              data-testid="api-base-input"
            />
            <button
              onClick={saveApiBase}
              className="w-full rounded-lg bg-primary py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
              data-testid="save-settings-button"
            >
              Save &amp; Reload
            </button>
          </div>
        </div>
      )}
    </>
  );
}
